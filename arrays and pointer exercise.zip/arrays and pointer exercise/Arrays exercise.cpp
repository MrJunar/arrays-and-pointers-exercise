#include <iostream>
#include <vector>
#include <string>

using namespace std;
int main()
{
    
    int sum = 0, product = 1, mean = 0, i = 0;
    int ten [] {10,20,30,40,50,60,70,80,90,100};
    for ( i=0 ; i<10 ; i++ ){
        sum  += ten[i];
        product = product * ten[i];
        mean = sum/10;
    }
        cout << sum << endl;
        cout<< product<<endl;
        cout<< mean<< endl;

    
}
