#include <iostream>
#include <vector>
#include <string>

using namespace std;
int main()
{
    
    double number1 = 7.3, number2;
    double* ptr = &number1;
    cout<< *ptr<<endl;
    number2 = *ptr;
    cout << &number1<<endl;
    cout << ptr<< endl;
    return 0;

    

    
}
